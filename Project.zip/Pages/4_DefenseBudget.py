import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Defence Budget Visualization", layout="wide")

st.title("💰 Global Defence Budget Dashboard")
st.markdown("Analyze defense spending trends, heatmaps, and country comparisons.")

@st.cache_data
def load_data():
    df = pd.read_csv("data/defence_budget_cleaned.csv", index_col=0)
    df.index.name = 'country'
    return df

df = load_data()
countries = df.index.tolist()

# Sidebar
selected = st.sidebar.multiselect("Select Countries", countries, default=countries[:5])
selected_df = df.loc[selected].T.reset_index().rename(columns={"index": "Year"})

# Line plot
st.subheader("📈 Budget Trend Over Time")
long_df = selected_df.melt(id_vars="Year", var_name="Country", value_name="Budget %")
fig = px.line(long_df, x="Year", y="Budget %", color="Country", markers=True,
              title="Defense Budget Percentage Over Time")
st.plotly_chart(fig, use_container_width=True)

# Heatmap
st.subheader("🌡️ Budget Heatmap")
heatmap_data = df.loc[selected]
fig2 = px.imshow(heatmap_data, aspect="auto", color_continuous_scale="Blues",
                 labels=dict(x="Year", y="Country", color="Budget %"))
st.plotly_chart(fig2, use_container_width=True)

# Histogram for spread
st.subheader("📊 Histogram of Budget % Values")
st.plotly_chart(px.histogram(long_df, x="Budget %", nbins=30, color="Country"), use_container_width=True)

# Boxplot comparison
st.subheader("📦 Budget Distribution per Country")
st.plotly_chart(px.box(long_df, x="Country", y="Budget %", color="Country"), use_container_width=True)

# Pie chart of most recent year
st.subheader("🥧 Budget Share (Latest Year)")
latest_year = df.columns[-1]
latest_vals = df[latest_year].dropna().sort_values(ascending=False).head(10)
st.plotly_chart(px.pie(values=latest_vals.values, names=latest_vals.index,
                       title=f"Top 10 Budget Spenders in {latest_year}"), use_container_width=True)

st.markdown("---")
st.markdown("Developed as part of The Art of War Visualization Series 🛡️")
