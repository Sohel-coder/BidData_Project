import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
from sklearn.linear_model import LinearRegression

st.set_page_config(page_title="Trade Visualization", layout="wide")

st.title("📦 Exports & Imports Dashboard")
st.markdown("Analyze trade patterns across countries through dynamic visualizations, forecasts, and maps.")

@st.cache_data
def load_data():
    df = pd.read_csv("data/exports_imports_cleaned.csv")
    df['trade_balance'] = df['export'] - df['import']
    return df

df = load_data()

# Sidebar filters
countries = df['country'].unique().tolist()
year_min, year_max = df['year'].min(), df['year'].max()
selected_countries = st.sidebar.multiselect("Select countries", countries, default=countries[:5])
selected_years = st.sidebar.slider("Select year range", year_min, year_max, (year_min, year_max))
filtered_df = df[(df['country'].isin(selected_countries)) & (df['year'].between(*selected_years))]

# Line chart
st.subheader("📈 Export & Import Over Time")
line_fig = px.line(filtered_df, x="year", y=["export", "import"], color="country", markers=True)
st.plotly_chart(line_fig, use_container_width=True)

# World Map
st.subheader("🌍 Trade Balance Map (Latest Year)")
latest_year_df = df[df['year'] == df['year'].max()]
map_fig = px.choropleth(latest_year_df, locations="country", locationmode="country names",
                        color="trade_balance", color_continuous_scale="RdBu",
                        title=f"Trade Balance in {df['year'].max()}", hover_name="country")
st.plotly_chart(map_fig, use_container_width=True)

# Pie charts
st.subheader("🍰 Export vs Import Share")
col1, col2 = st.columns(2)
with col1:
    pie_exp = df.groupby("country")["export"].sum().nlargest(10)
    st.plotly_chart(px.pie(names=pie_exp.index, values=pie_exp.values, title="Top 10 Exporters"))
with col2:
    pie_imp = df.groupby("country")["import"].sum().nlargest(10)
    st.plotly_chart(px.pie(names=pie_imp.index, values=pie_imp.values, title="Top 10 Importers"))

# Forecast
st.subheader("🔮 Forecast Export/Import")
selected_country = st.selectbox("Select a country for forecasting", countries)
country_df = df[df['country'] == selected_country]

def forecast_trend(y_col):
    model = LinearRegression()
    X = country_df['year'].values.reshape(-1, 1)
    y = country_df[y_col].values
    model.fit(X, y)
    future_years = np.arange(df['year'].max() + 1, df['year'].max() + 6).reshape(-1, 1)
    future_preds = model.predict(future_years)
    return future_years.flatten(), future_preds

exp_years, exp_forecast = forecast_trend('export')
imp_years, imp_forecast = forecast_trend('import')

fig_pred = go.Figure()
fig_pred.add_trace(go.Scatter(x=country_df['year'], y=country_df['export'], mode='lines+markers', name='Export'))
fig_pred.add_trace(go.Scatter(x=exp_years, y=exp_forecast, mode='lines', name='Export Forecast'))
fig_pred.add_trace(go.Scatter(x=country_df['year'], y=country_df['import'], mode='lines+markers', name='Import'))
fig_pred.add_trace(go.Scatter(x=imp_years, y=imp_forecast, mode='lines', name='Import Forecast'))
fig_pred.update_layout(title=f"{selected_country} - Export & Import Forecast", xaxis_title="Year", yaxis_title="USD")
st.plotly_chart(fig_pred, use_container_width=True)

# Histogram
st.subheader("📊 Distribution of Trade Balance")
st.plotly_chart(px.histogram(df, x="trade_balance", nbins=50, title="Trade Balance Distribution"), use_container_width=True)

# Box Plot
st.subheader("📦 Trade Boxplot per Country")
box_df = df[df['country'].isin(selected_countries)]
st.plotly_chart(px.box(box_df, x="country", y="trade_balance", color="country", title="Trade Balance Spread"), use_container_width=True)

st.markdown("---")
st.markdown("Developed as part of The Art of War Visualization Series 🛡️")
