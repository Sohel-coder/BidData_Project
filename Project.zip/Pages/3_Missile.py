import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Missile Data Visualization", layout="wide")

st.title("🚀 Missile Capability Dashboard")
st.markdown("Explore missile systems across families, speeds, and operational ranges.")

@st.cache_data
def load_data():
    return pd.read_csv("data/missiles_cleaned.csv")

missiles_df = load_data()

# Sidebar filter
families = missiles_df['Family'].dropna().unique().tolist()
selected_family = st.sidebar.selectbox("Select Missile Family", sorted(families))
filtered_df = missiles_df[missiles_df['Family'] == selected_family]

# Range bar chart
st.subheader(f"📏 Maximum Ranges - {selected_family}")
fig = px.bar(filtered_df, x='Name', y='Maximum range', color='Status',
             hover_data=['Type', 'Speed'],
             title=f"Missile Ranges in {selected_family} Family")
st.plotly_chart(fig, use_container_width=True)

# Pie chart of Status distribution
st.subheader("🧩 Status Distribution")
st.plotly_chart(px.pie(filtered_df, names='Status', title="Missile Status Breakdown"), use_container_width=True)

# Histogram of range
st.subheader("📊 Range Distribution")
st.plotly_chart(px.histogram(filtered_df, x='Maximum range', nbins=30, title="Missile Range Distribution"), use_container_width=True)

# Box plot by Type
st.subheader("📦 Range by Missile Type")
st.plotly_chart(px.box(filtered_df, x='Type', y='Maximum range', color='Type',
                       title="Range Spread by Missile Type"), use_container_width=True)

# Speed vs Range scatter plot
st.subheader("⚡ Speed vs Range")
st.plotly_chart(px.scatter(filtered_df, x='Speed', y='Maximum range', color='Status',
                           hover_name='Name', size='Maximum range',
                           title="Missile Speed vs Range"), use_container_width=True)

st.markdown("---")
st.markdown("Developed as part of The Art of War Visualization Series 🛡️")
