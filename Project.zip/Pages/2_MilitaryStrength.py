import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Military Strength Visualization", layout="wide")

st.title("🪖 Global Military Strength Dashboard")
st.markdown("Explore the manpower, equipment, and power index across global military forces.")

@st.cache_data
def load_data():
    return pd.read_csv("data/military_strength_cleaned.csv")

military_df = load_data()

# Sidebar filters
countries = military_df['country'].unique().tolist()
selected_countries = st.sidebar.multiselect("Select countries", countries, default=countries[:5])
filtered_df = military_df[military_df['country'].isin(selected_countries)]

# Power Index Bar Chart
st.subheader("🔥 Global Power Index (Lower is Stronger)")
pwr_fig = px.bar(military_df.sort_values("pwr_index"), x='country', y='pwr_index', color='pwr_index',
                 title="Countries by Power Index (Top 20)",
                 hover_data=['active_service_military_manpower', 'total_military_aircraft_strength'])
st.plotly_chart(pwr_fig, use_container_width=True)

# Manpower vs Power Index
st.subheader("👥 Manpower vs Power Index")
scatter_fig = px.scatter(military_df, x="active_service_military_manpower", y="pwr_index",
                         size="total_military_aircraft_strength", color="country",
                         title="Power Index vs Active Military Manpower",
                         hover_name="country", size_max=50)
st.plotly_chart(scatter_fig, use_container_width=True)

# Histogram
st.subheader("📊 Distribution of Power Index")
st.plotly_chart(px.histogram(military_df, x="pwr_index", nbins=30, title="Power Index Histogram"), use_container_width=True)

# Pie Chart of Aircraft Strength (top 10)
st.subheader("✈️ Total Aircraft Distribution (Top 10)")
aircraft_df = military_df.nlargest(10, 'total_military_aircraft_strength')
st.plotly_chart(px.pie(aircraft_df, names='country', values='total_military_aircraft_strength',
                       title="Aircraft Strength by Country"), use_container_width=True)

# Box plot of manpower
st.subheader("📦 Active Military Manpower Distribution")
st.plotly_chart(px.box(military_df, y='active_service_military_manpower', points="all",
                       title="Distribution of Active Military Personnel"), use_container_width=True)

# Dynamic selection scatter
st.subheader("🔍 Compare Custom Countries")
metric = st.selectbox("Choose metric to compare", [
    'active_service_military_manpower',
    'total_military_aircraft_strength',
    'total_national_populations',
    'pwr_index'])
metric_fig = px.bar(filtered_df.sort_values(metric, ascending=False),
                    x='country', y=metric, color='country', title=f"Selected Countries by {metric.replace('_', ' ').title()}")
st.plotly_chart(metric_fig, use_container_width=True)

st.markdown("---")
st.markdown("Developed as part of The Art of War Visualization Series 🛡️")
