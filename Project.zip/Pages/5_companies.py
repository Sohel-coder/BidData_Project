import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Defence Companies Visualization", layout="wide")

st.title("🏭 Global Defence Companies Dashboard")
st.markdown("Track the evolution, revenue, and nationality of major defense companies worldwide.")

@st.cache_data
def load_data():
    return pd.read_csv("data/defence_companies_from_2005_final.csv")

df = load_data()

# Sidebar filters
years = sorted(df['year'].unique())
companies = df['company_name'].unique().tolist()
countries = df['country'].unique().tolist()

selected_year = st.sidebar.selectbox("Select Year", years)
selected_companies = st.sidebar.multiselect("Select Companies", companies, default=companies[:5])
selected_country = st.sidebar.selectbox("Filter by Country", ["All"] + countries)

filtered_df = df[df['year'] == selected_year]
if selected_country != "All":
    filtered_df = filtered_df[filtered_df['country'] == selected_country]
if selected_companies:
    filtered_df = filtered_df[filtered_df['company_name'].isin(selected_companies)]

# Revenue bar chart
st.subheader(f"💸 Company Revenue in {selected_year}")
fig = px.bar(filtered_df.sort_values("revenue", ascending=False),
             x='company_name', y='revenue', color='country',
             title="Defense Company Revenue", hover_data=['rank'])
st.plotly_chart(fig, use_container_width=True)

# Country-wise revenue share pie
st.subheader("🌍 Country-wise Revenue Share")
country_revenue = filtered_df.groupby('country')['revenue'].sum().sort_values(ascending=False)
st.plotly_chart(px.pie(values=country_revenue.values, names=country_revenue.index,
                       title="Revenue by Country"), use_container_width=True)

# Rank vs Revenue Scatter
st.subheader("📈 Company Rank vs Revenue")
st.plotly_chart(px.scatter(filtered_df, x="rank", y="revenue", color='company_name',
                           size='revenue', hover_name='company_name',
                           title="Company Rank vs Revenue"), use_container_width=True)

# Yearly evolution line plot
st.subheader("📊 Top Companies Over Time")
top_companies = df.groupby('company_name')['revenue'].sum().nlargest(5).index.tolist()
top_df = df[df['company_name'].isin(top_companies)]
fig = px.line(top_df, x="year", y="revenue", color="company_name", markers=True,
              title="Top 5 Companies by Revenue Over Time")
st.plotly_chart(fig, use_container_width=True)

st.markdown("---")
st.markdown("Developed as part of The Art of War Visualization Series 🛡️")
