import streamlit as st
import streamlit.components.v1 as components

st.set_page_config(page_title="The Art of War - Dashboard", layout="wide")

# Sidebar Navigation with sliding menu style
st.markdown("""
    <style>
        [data-testid="stSidebarNav"] ul {
            background-color: #f0f2f6;
            padding: 20px;
        }
        [data-testid="stSidebarNav"] li {
            margin-bottom: 15px;
        }
    </style>
""", unsafe_allow_html=True)

st.sidebar.title("🛡️ The Art of War")
page = st.sidebar.radio("Navigate to Section", [
    "📦 Trade Visualization",
    "🪖 Military Strength Visualization",
    "🚀 Missile Data Visualization",
    "💰 Defence Budget Visualization",
    "🏭 Defence Companies Visualization"
])

st.title("🛡️ The Art of War: Global Defense Analytics Platform")

st.markdown("""
Welcome to **The Art of War**, a comprehensive visualization suite showcasing military and defense analytics across nations. Select a section from the menu to begin exploring:
- 🌍 Country-level trade and economic impact
- 🪖 Military strength and global power comparison
- 🚀 Missile technology and range distribution
- 💰 National defense budget trends
- 🏭 Evolution of defense corporations and industries
""")

# Dynamically load selected script content
if page == "📦 Trade Visualization":
    with open("Pages/1_TradeAnalysis.py", encoding="utf-8") as f:
        exec(f.read())
elif page == "🪖 Military Strength Visualization":
    with open("Pages/2_MilitaryStrength.py", encoding="utf-8") as f:
        exec(f.read())
elif page == "🚀 Missile Data Visualization":
    with open("Pages/3_Missile.py", encoding="utf-8") as f:
        exec(f.read())
elif page == "💰 Defence Budget Visualization":
    with open("Pages/4_DefenseBudget.py", encoding="utf-8") as f:
        exec(f.read())
elif page == "🏭 Defence Companies Visualization":
    with open("Pages/5_companies.py", encoding="utf-8") as f:
        exec(f.read())

st.markdown("---")
